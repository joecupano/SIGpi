#!/bin/sh

export VERS="3.07"
export MAJVERS="3"

echo "Installing SDRplay RSP API library ${VERS}..."
read -p "Press RETURN to view the license agreement" ret

more sdrplay_license.txt

while true; do
    echo "Press y and RETURN to accept the license agreement and continue with"
    read -p "the installation, or press n and RETURN to exit the installer [y/n] " yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
        * ) echo "Please answer y or n";;
    esac
done

export ARCH=`uname -m`

echo "Architecture: ${ARCH}"
echo "API Version: ${VERS}"

if [ "${ARCH}" != "aarch64" ]; then
	if [ "${ARCH}" != "arm64" ]; then
		echo "The architecture on this device (${ARCH}) is not currently supported."
		echo "Please contact software@sdrplay.com for details on platform support."
		exit 1
	fi
fi

echo "If not installing as root, you will be prompted for your password"
echo "for sudo access to the /usr/local area..."
sudo mkdir -p /usr/local/lib >> /dev/null 2>&1
echo "The rest of the installation will continue with root permission..."

if [ -d "/etc/udev/rules.d" ]; then
	echo -n "Udev rules directory found, adding rules..."
	sudo cp -f 66-mirics.rules /etc/udev/rules.d/66-mirics.rules
	sudo chmod 644 /etc/udev/rules.d/66-mirics.rules
    echo "Done"
else
	echo " "
	echo "ERROR: udev rules directory not found, add udev support and run the"
	echo "installer again. udev support can be added by running..."
	echo "sudo apt-get install libudev-dev"
	echo " "
	exit 1
fi

if /sbin/ldconfig -p | /bin/fgrep -q libusb-1.0; then
	echo "Libusb found, continuing..."
else
	echo " "
	echo "ERROR: Libusb cannot be found. Please install libusb and then run"
	echo "the installer again. Libusb can be installed by running..."
    echo "sudo apt-get install libusb-1.0.0-dev"
	echo " "
	exit 1
fi

export TYPE="LOCAL"
if [ -d "/usr/local/lib" ]; then
    if [ -d "/usr/local/include" ]; then
        if [ -d "/usr/local/bin" ]; then
            echo "Installing files into /usr/local (/lib, /bin, /include)..."
            export INSTALLLIBDIR="/usr/local/lib"
            export INSTALLINCDIR="/usr/local/include"
            export INSTALLBINDIR="/usr/local/bin"
        else
            TYPE="USR"
        fi
    else
        TYPE="USR"
    fi
else
    TYPE="USR"
fi

if [ "${TYPE}" != "LOCAL" ]; then
    echo "Installing files into /usr (/lib, /bin, /include)..."
    export INSTALLLIBDIR="/usr/lib"
    export INSTALLINCDIR="/usr/include"
    export INSTALLBINDIR="/usr/bin"
fi

echo -n "Installing ${INSTALLLIBDIR}/libsdrplay_api.so.${VERS}..."
sudo rm -f ${INSTALLLIBDIR}/libsdrplay_api.so.${VERS}
sudo cp -f ${ARCH}/libsdrplay_api.so.${VERS} ${INSTALLLIBDIR}/.
sudo chmod 644 ${INSTALLLIBDIR}/libsdrplay_api.so.${VERS}
sudo rm -f ${INSTALLLIBDIR}/libsdrplay_api.so.${MAJVERS}
sudo ln -s ${INSTALLLIBDIR}/libsdrplay_api.so.${VERS} ${INSTALLLIBDIR}/libsdrplay_api.so.${MAJVERS}
sudo rm -f ${INSTALLLIBDIR}/libsdrplay_api.so
sudo ln -s ${INSTALLLIBDIR}/libsdrplay_api.so.${MAJVERS} ${INSTALLLIBDIR}/libsdrplay_api.so
echo "Done"

echo -n "Installing header files in ${INSTALLINCDIR}..."
sudo cp -f inc/sdrplay_api*.h ${INSTALLINCDIR}/.
sudo chmod 644 ${INSTALLINCDIR}/sdrplay_api*.h
echo "Done"

echo -n "Installing API Service in ${INSTALLBINDIR}..."
sudo cp -f ${ARCH}/sdrplay_apiService ${INSTALLBINDIR}/sdrplay_apiService
echo "Done"

echo -n "Installing Service scripts and starting daemon..."
if [ -d "/etc/systemd/system" ]; then
    export SRVTYPE="systemd"
    if [ "${TYPE}" != "LOCAL" ]; then
        sudo cp -f sdrplay.service.usr /etc/systemd/system/sdrplay.service
    else
        sudo cp -f sdrplay.service.local /etc/systemd/system/sdrplay.service
    fi
    sudo chmod 644 /etc/systemd/system/sdrplay.service
    sudo systemctl start sdrplay
    sudo systemctl enable sdrplay
    sudo systemctl daemon-reload
    sudo systemctl restart sdrplay
else
    export SRVTYPE="initd"
    if [ "${TYPE}" != "LOCAL" ]; then
        sudo cp -f sdrplayService_usr /etc/init.d/sdrplayService
    else
        sudo cp -f sdrplayService_local /etc/init.d/sdrplayService
    fi
    sudo chmod 755 /etc/init.d/sdrplayService
    sudo update-rc.d sdrplayService defaults
    sudo service sdrplayService start
    sudo ldconfig
fi

echo "Done"

echo " "
echo "Service has been installed and started. This device should be rebooted"
echo "before the service is used. After the installation script finishes,"
echo "reboot this device."

echo " "
echo "To start and stop the API service, use the following commands..."
echo " "
if [ "${SRVTYPE}" != "systemd" ]; then
    echo "sudo service sdrplayService start"
    echo "sudo service sdrplayService stop"
else
    echo "sudo systemctl start sdrplay"
    echo "sudo systemctl stop sdrplay"
fi
echo " "
echo "SDRplay API ${VERS} Installation Finished"
echo " "
